import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// UPDATE person
export async function PUT(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    const { name, category, description, emoji, imageUrl } = body
    
    const person = await prisma.person.update({
      where: { id: params.id },
      data: {
        name,
        category,
        description,
        emoji,
        imageUrl
      }
    })
    
    return NextResponse.json(person)
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to update person' },
      { status: 500 }
    )
  }
}

// DELETE person
export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    await prisma.person.delete({
      where: { id: params.id }
    })
    
    return NextResponse.json({ success: true })
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to delete person' },
      { status: 500 }
    )
  }
}
