import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET() {
  try {
    const people = await prisma.person.findMany({
      orderBy: {
        totalBoosts: 'desc'
      }
    })
    
    return NextResponse.json(people)
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to fetch people' },
      { status: 500 }
    )
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { name, category, description, emoji, imageUrl } = body
    
    const person = await prisma.person.create({
      data: {
        name,
        category,
        description,
        emoji: emoji || '👤',
        imageUrl: imageUrl || null
      }
    })
    
    return NextResponse.json(person)
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to create person' },
      { status: 500 }
    )
  }
}
