import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/app/api/auth/[...nextauth]/route'
import { prisma } from '@/lib/prisma'

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      )
    }
    
    const body = await request.json()
    const { personId, amount } = body
    
    if (!personId || !amount || amount <= 0) {
      return NextResponse.json(
        { error: 'Invalid request' },
        { status: 400 }
      )
    }
    
    // Check user has enough tokens
    const user = await prisma.user.findUnique({
      where: { id: session.user.id }
    })
    
    if (!user || user.tokens < amount) {
      return NextResponse.json(
        { error: 'Insufficient tokens' },
        { status: 400 }
      )
    }
    
    // Use transaction to ensure atomicity
    const result = await prisma.$transaction(async (tx) => {
      // Deduct tokens from user
      await tx.user.update({
        where: { id: session.user.id },
        data: { tokens: { decrement: amount } }
      })
      
      // Update person stats
      const person = await tx.person.update({
        where: { id: personId },
        data: {
          totalBoosts: { increment: amount },
          supporters: { increment: 1 }
        }
      })
      
      // Create transaction record
      await tx.transaction.create({
        data: {
          userId: session.user.id,
          personId,
          type: 'boost',
          amount: -amount,
          description: `Boosted ${person.name}`
        }
      })
      
      return person
    })
    
    return NextResponse.json(result)
  } catch (error) {
    console.error('Boost error:', error)
    return NextResponse.json(
      { error: 'Failed to boost' },
      { status: 500 }
    )
  }
}
