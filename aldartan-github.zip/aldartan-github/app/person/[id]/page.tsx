'use client'

import { useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Image from 'next/image'

interface Person {
  id: string
  name: string
  category: string
  description: string
  emoji: string
  imageUrl?: string | null
  totalBoosts: number
  supporters: number
}

export default function PersonPage({ params }: { params: { id: string } }) {
  const { data: session } = useSession()
  const router = useRouter()
  const [person, setPerson] = useState<Person | null>(null)
  const [boostAmount, setBoostAmount] = useState(100)
  const [loading, setLoading] = useState(true)
  const [boosting, setBoosting] = useState(false)

  useEffect(() => {
    fetchPerson()
  }, [params.id])

  const fetchPerson = async () => {
    try {
      const response = await fetch('/api/people')
      const data = await response.json()
      const foundPerson = data.find((p: Person) => p.id === params.id)
      setPerson(foundPerson || null)
    } catch (error) {
      console.error('Failed to fetch person:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleBoost = async () => {
    if (!session) {
      router.push('/login')
      return
    }

    setBoosting(true)
    try {
      const response = await fetch('/api/boost', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          personId: params.id,
          amount: boostAmount
        })
      })

      if (response.ok) {
        alert('Амжилттай boost өглөө!')
        fetchPerson()
        router.refresh()
      } else {
        const error = await response.json()
        alert(error.error || 'Алдаа гарлаа')
      }
    } catch (error) {
      alert('Алдаа гарлаа')
    } finally {
      setBoosting(false)
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-96">
        <div className="text-white text-2xl">Уншиж байна...</div>
      </div>
    )
  }

  if (!person) {
    return (
      <div className="card p-8 text-center">
        <h1 className="text-2xl font-bold">Хүн олдсонгүй</h1>
      </div>
    )
  }

  const getRankBadge = () => {
    // This is simplified - in production you'd get the actual rank
    return '🏆'
  }

  return (
    <div className="card p-10">
      <div className="flex gap-8 mb-8">
        <div className="w-52 h-52 bg-gradient-to-br from-gray-100 to-gray-200 rounded-2xl flex items-center justify-center overflow-hidden relative flex-shrink-0">
          {person.imageUrl ? (
            <Image 
              src={person.imageUrl} 
              alt={person.name}
              fill
              className="object-cover"
            />
          ) : (
            <span className="text-8xl">{person.emoji}</span>
          )}
        </div>
        
        <div className="flex-1">
          <div className="text-4xl mb-2">{getRankBadge()}</div>
          <h1 className="text-4xl font-bold text-gray-800 mb-2">{person.name}</h1>
          <p className="text-xl text-gray-600 mb-5">{person.category}</p>
          <p className="text-gray-700 leading-relaxed mb-6">{person.description}</p>
          
          <div className="flex gap-8">
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">{person.totalBoosts.toLocaleString()}</div>
              <div className="text-sm text-gray-500 mt-1">Нийт Boost</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">{person.supporters}</div>
              <div className="text-sm text-gray-500 mt-1">Supporters</div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-gray-50 p-6 rounded-xl">
        <h3 className="text-xl font-bold mb-4">💎 Boost өгөх</h3>
        <p className="text-gray-600 mb-4">Токен ашиглан энэ хүнийг дэмжээрэй!</p>
        
        <div className="flex gap-4 items-center">
          <input
            type="number"
            value={boostAmount}
            onChange={(e) => setBoostAmount(Number(e.target.value))}
            min="1"
            className="input flex-1"
            placeholder="Токен тоо"
          />
          <button
            onClick={handleBoost}
            disabled={boosting || !session}
            className="btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {boosting ? 'Илгээж байна...' : 'Boost өгөх'}
          </button>
        </div>
        
        {session && (
          <p className="text-gray-500 text-sm mt-3">
            Таны үлдэгдэл: {session.user?.tokens || 0} токен
          </p>
        )}
        
        {!session && (
          <p className="text-red-500 text-sm mt-3">
            Boost өгөхийн тулд эхлээд нэвтэрнэ үү
          </p>
        )}
      </div>
    </div>
  )
}
