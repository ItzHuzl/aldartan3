'use client'

import { useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'

interface Transaction {
  id: string
  type: string
  amount: number
  description: string
  createdAt: string
  person?: {
    name: string
  }
}

interface UserData {
  id: string
  name: string
  email: string
  tokens: number
  transactions: Transaction[]
}

export default function Dashboard() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [userData, setUserData] = useState<UserData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login')
    } else if (status === 'authenticated') {
      fetchUserData()
    }
  }, [status, router])

  const fetchUserData = async () => {
    try {
      const response = await fetch('/api/user')
      if (response.ok) {
        const data = await response.json()
        setUserData(data)
      }
    } catch (error) {
      console.error('Failed to fetch user data:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading || status === 'loading') {
    return (
      <div className="flex justify-center items-center h-96">
        <div className="text-white text-2xl">Уншиж байна...</div>
      </div>
    )
  }

  if (!userData) {
    return null
  }

  const totalBoosts = userData.transactions.filter(t => t.type === 'boost').length
  const totalSpent = userData.transactions
    .filter(t => t.type === 'boost')
    .reduce((sum, t) => sum + Math.abs(t.amount), 0)

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="card p-6">
          <h3 className="text-gray-600 text-lg mb-2">Миний токен</h3>
          <div className="text-4xl font-bold text-primary mb-4">💎 {userData.tokens.toLocaleString()}</div>
          <button className="btn-primary w-full">Токен худалдаж авах</button>
        </div>

        <div className="card p-6">
          <h3 className="text-gray-600 text-lg mb-2">Өгсөн Boost</h3>
          <div className="text-4xl font-bold text-primary">{totalBoosts}</div>
          <p className="text-gray-500 mt-2">Нийт {totalSpent.toLocaleString()} токен зарцуулсан</p>
        </div>

        <div className="card p-6">
          <h3 className="text-gray-600 text-lg mb-2">Дэмжсэн хүмүүс</h3>
          <div className="text-4xl font-bold text-primary">
            {new Set(userData.transactions.filter(t => t.person).map(t => t.person?.name)).size}
          </div>
          <p className="text-gray-500 mt-2">Өөр өөр хүмүүс</p>
        </div>
      </div>

      <div className="card p-6">
        <h3 className="text-2xl font-bold mb-6">📜 Гүйлгээний түүх</h3>
        
        {userData.transactions.length === 0 ? (
          <p className="text-center text-gray-500 py-10">Гүйлгээ байхгүй байна</p>
        ) : (
          <div className="space-y-4">
            {userData.transactions.map((transaction) => (
              <div
                key={transaction.id}
                className="flex justify-between items-center py-4 border-b border-gray-100 last:border-0"
              >
                <div>
                  <p className="font-semibold text-gray-800">
                    {transaction.description || transaction.type}
                  </p>
                  <p className="text-sm text-gray-500">
                    {new Date(transaction.createdAt).toLocaleString('mn-MN')}
                  </p>
                </div>
                <div className={`text-xl font-bold ${transaction.amount < 0 ? 'text-red-500' : 'text-green-500'}`}>
                  {transaction.amount > 0 ? '+' : ''}{transaction.amount} токен
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
